package com.tyz.model.enums;

public interface BaseEnum {

    Integer getCode();

    String getName();
}
