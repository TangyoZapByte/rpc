package com.tyz.web.admin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tyz.model.entity.Sharerecord;

public interface SharerecordMapper extends BaseMapper<Sharerecord> {
}
