package com.tyz.web.admin.vo;

import lombok.Data;

@Data
public class HoldVo {
    private Long AccountId;

    private Long FundId;
}
