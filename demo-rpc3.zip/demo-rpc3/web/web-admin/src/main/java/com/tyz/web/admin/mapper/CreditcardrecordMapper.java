package com.tyz.web.admin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tyz.model.entity.Creditcardrecord;

public interface CreditcardrecordMapper extends BaseMapper<Creditcardrecord> {
}
