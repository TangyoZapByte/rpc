package com.tyz.web.admin.vo;

import lombok.Data;

@Data
public class WithdrawOrderVo {
    private Long TransactionId;

    private Long FundId;
}
